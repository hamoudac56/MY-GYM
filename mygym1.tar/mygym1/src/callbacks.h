#include <gtk/gtk.h>

void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_clist1_select_row                   (GtkCList        *clist,
                                        gint             row,
                                        gint             column,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button8_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

gboolean
on_label55_activate_link               (GtkLabel        *label,
                                        gchar           *arg1,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);
