void afficher();
