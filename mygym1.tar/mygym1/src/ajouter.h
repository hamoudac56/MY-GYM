void ajouter(char login[], char password[],int role);
