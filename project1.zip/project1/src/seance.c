
#include <stdio.h>
#include <string.h>
#include "seance.h"

void ajouter_seance(seance s)
{

 FILE *f;
  f=fopen("liste.txt","a+");
  if(f!=NULL)
  {
      
     fprintf(f,"%s %d %d %d %d %d\n",s.specialite,s.heure,s.jour,s.mois,s.annee,s.num_seance);
     fclose(f);

  }

}

