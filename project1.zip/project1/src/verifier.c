#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"verifier.h"
int verifier(char login[], char password[])
{
        FILE*f;
       	char temppass[20]; char templog[20];
        f=fopen("/home/bayar/Projects/project1/src/donnee.txt","r");
        int verif=-1;
	int role;

        if(f !=NULL) 
	{
        while(fscanf(f,"%s %s %d \n",templog,temppass,&role)!=EOF)
        {
        if(strcmp(login,templog)==0 && strcmp(password,temppass)==0)
                verif=1;
        }
	fclose(f);
        }
        return (verif);
	}
