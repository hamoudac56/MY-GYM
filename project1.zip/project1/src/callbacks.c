#ifdef HAVE_CONFIG_H
#include<config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "verifier.h"
#include "seance.h"
#include "disponibilitee_coach.h"
#include "liste_seance.h"
#include "adherant.h"



void
on_button1_clicked   (GtkWidget *objet_graphique, gpointer  user_data)
{
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *output;
GtkWidget *window3;
GtkWidget *window1;
char login[20],password[20];

input1=lookup_widget(objet_graphique,"entry1");
input2=lookup_widget(objet_graphique,"entry2");
output=lookup_widget(objet_graphique,"label4");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));

if(verifier(login,password)==1)
{window1=lookup_widget(objet_graphique,"window1");
	gtk_widget_hide(window1);
	window3=create_window3();
	gtk_widget_show(window3);
}
else if (verifier(login,password)==-1)
{gtk_label_set_text(GTK_LABEL(output),"login ou pwd erronee");
}
}






void
on_button3_clicked          (GtkWidget  *objet_graphique,       gpointer         user_data)
{
GtkWidget *combobox1;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *num_seance;
GtkWidget *combobox2;
GtkWidget *label18;
char specialite[100];
seance s;

// associé les objets avec des variables
combobox1=lookup_widget(objet_graphique, "combobox1");
jour=lookup_widget(objet_graphique, "spinbutton1");
mois=lookup_widget(objet_graphique, "spinbutton2");
annee=lookup_widget(objet_graphique, "spinbutton3");
num_seance=lookup_widget(objet_graphique, "spinbutton4");
label18=lookup_widget(objet_graphique, "label18");
combobox2=lookup_widget(objet_graphique, "combobox2");
strcpy(s.specialite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
 
s.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
s.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
s.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
s.num_seance=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (num_seance));
if(strcmp("8-10",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)  s.heure=1;
if(strcmp("10-12",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)  s.heure=2;
if(strcmp("12-14",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)  s.heure=3;
if(strcmp("14-16",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)  s.heure=4;
if(strcmp("16-18",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)  s.heure=5;
if(strcmp("18-20",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)  s.heure=6;

ajouter_seance(s);
gtk_label_set_text(GTK_LABEL(label18),"Séance ajoutée");


}




on_button2_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window3;
GtkWidget *window4;
GtkWidget *treeview1;
listes li;

gtk_widget_hide(window3);
gtk_widget_destroy(window3);

window4=create_window4();

gtk_widget_show(window4);
      

treeview1=lookup_widget(window4,"treeview1");

afficher_listes(treeview1); 



}


void
on_button4_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


GtkWidget *window3;
GtkWidget *window4;
gtk_widget_destroy(window3);
window4=lookup_widget(objet_graphique,"window4");

gtk_widget_destroy(window4);
gtk_widget_hide(window3);
gtk_widget_show(window3);

}


void
on_button5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{
  GtkWidget *combobox3;
  GtkWidget *jour1;
  GtkWidget *mois1;
  GtkWidget *annee1;
  GtkWidget *num_seance1;
  GtkWidget *combobox4;
  char num[10];
  listes lm;

  // associé les objets avec des variables
combobox4=lookup_widget(objet_graphique, "combobox4"); 
combobox3=lookup_widget(objet_graphique, "combobox3");
jour1=lookup_widget(objet_graphique, "spinbutton5");
mois1=lookup_widget(objet_graphique, "spinbutton6");
annee1=lookup_widget(objet_graphique, "spinbutton7");
num_seance1=lookup_widget(objet_graphique, "spinbutton8");
strcpy(num,gtk_entry_get_text(GTK_ENTRY(num_seance1)));          strcpy(lm.specialite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox4)));
strcpy(lm.heure,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)));
strcpy(lm.jour,gtk_entry_get_text(GTK_ENTRY(jour1)));
strcpy(lm.mois,gtk_entry_get_text(GTK_ENTRY(mois1)));
strcpy(lm.annee,gtk_entry_get_text(GTK_ENTRY(annee1)));
strcpy(lm.num_seance,gtk_entry_get_text(GTK_ENTRY(num_seance1))); 

  modifier_seance(num,lm);
}
void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *num_supp;

char numm_supp[20];
listes li;

num_supp=lookup_widget(objet_graphique,"spinbutton12");


strcpy(numm_supp,gtk_entry_get_text(GTK_ENTRY(num_supp)));

supprimer_seance(numm_supp);
}



void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *window3;
GtkWidget *window5;
GtkWidget *treeview2;
personne p;
gtk_widget_hide(window3);
gtk_widget_destroy(window3);

window5=create_window5();

gtk_widget_show(window5);
      

treeview2=lookup_widget(window5,"treeview2");

afficher_personne(treeview2);

}


void
on_button8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *window3;
  GtkWidget *window5;
  gtk_widget_destroy(window3);
  window5=lookup_widget(objet_graphique,"window5");

  gtk_widget_destroy(window5);
  gtk_widget_hide(window3);
  gtk_widget_show(window3);    
}


void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
   GtkWidget *window3;
GtkWidget *window6;
GtkWidget *treeview3;
disponibilitee d ;
gtk_widget_hide(window3);
gtk_widget_destroy(window3);

window6=create_window6();

gtk_widget_show(window6);
      

treeview3=lookup_widget(window6,"treeview3");

disponibilitee_coach(treeview3);

}


void
on_button10_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *window3;
  GtkWidget *window6;
  gtk_widget_destroy(window3);
  window6=lookup_widget(objet_graphique,"window6");

  gtk_widget_destroy(window6);
  gtk_widget_hide(window3);
  gtk_widget_show(window3);
}

