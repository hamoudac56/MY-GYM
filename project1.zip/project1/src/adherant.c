#include <stdio.h>
#include <string.h>


#include "adherant.h"
enum 
{
       NOM_AH,
       PRENOM_AH,
       AGE,
       IMC,
       SEXE,
       SANG,
       REGIME,
       COLUMNS
};

void afficher_personne(GtkWidget *liste) 
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char nom_ah[10];
	char prenom_ah[10];
	char age[10];
	char imc[10];
        char sexe[10];
        char sang[10];
        char regime[30];
        store=NULL;

       FILE *h;
	
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" nom_ah", renderer, "text",NOM_AH, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" prenom_ah", renderer, "text",PRENOM_AH, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" age", renderer, "text",AGE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" imc", renderer, "text",IMC, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" sexe", renderer, "text",SEXE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
               
                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" sang", renderer, "text",SANG, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" regime", renderer, "text",REGIME, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
                
	
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	h = fopen("donnee_personnel.txt", "r");
	
	if(h==NULL)
	{

		return;
	}		
	else 

	{ h = fopen("donnee_personnel.txt", "a+");
              while(fscanf(h,"%s %s %s %s %s %s %s\n",nom_ah,prenom_ah,age,imc,sexe,sang,regime)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, NOM_AH, nom_ah, PRENOM_AH, prenom_ah, AGE, age, IMC, imc , SEXE, sexe, SANG, sang, REGIME, regime -1); 
		}
		fclose(h);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}
