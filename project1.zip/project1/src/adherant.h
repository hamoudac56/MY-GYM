#include <gtk/gtk.h>


typedef struct 
{
        char nom_ah[10];
	char prenom_ah[10];
	char age[10];
	char imc[10];
        char sexe[10];
        char sang[10];
        char regime[30];     
} personne;
void afficher_personne(GtkWidget *liste) ;

