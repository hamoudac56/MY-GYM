
#include <stdio.h>
#include <string.h>
#include "liste_seance.h"

enum   
{       
       
        SPECIALITE,
        HEURE,
	JOUR,
        MOIS,
        ANNEE,
        NUM_SEANCE,
        COLUMNS

};
int ver(char option[])
{
	FILE*f;
	listes li;
	int exist=-1;
	
f=fopen("liste.txt" , "r");
if (f!=NULL)
{	while (fscanf(f,"%s " , li.specialite)!=EOF)
		{ if (strcmp(option,li.specialite)==0 )
			exist=1;	
		}

}
fclose(f);

return(exist);						
}



void ajouter_listes(listes li)
{
	FILE *f;
	f=fopen("liste.txt","a+");
	if (f!=NULL)
		{ fprintf(f,"%s %s %s %s %s %s %s %s\n",li.specialite,li.heure, li.jour , li.mois,li.annee,li.num_seance );
		fclose(f);
		}
}



void afficher_listes(GtkWidget *liste) 
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char specialite[100];
	char heure[50];
	char jour[50];
	char mois[50];
        char annee[50];
        char num_seance[50];
        store=NULL;

       FILE *f;
	
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" specialite", renderer, "text",SPECIALITE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" heure", renderer, "text",HEURE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" jour", renderer, "text",JOUR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" mois", renderer, "text",MOIS, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" annee", renderer, "text",ANNEE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
               
                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" num_seance", renderer, "text",NUM_SEANCE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
                
	
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("liste.txt", "r");
	
	if(f==NULL)
	{

		return;
	}		
	else 

	{ f = fopen("liste.txt", "a+");
              while(fscanf(f,"%s %s %s %s %s %s\n",specialite,heure,jour,mois,annee,num_seance)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, SPECIALITE, specialite, HEURE, heure, JOUR, jour, MOIS, mois , ANNEE, annee, NUM_SEANCE, num_seance, -1); 
		}
		fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}
void supprimer_seance(char num[10])
{	
	FILE*f ,*j;
    	listes li;

    	f=fopen("liste.txt","a+");
	    j=fopen("liste.tmp.txt","a+");
	if(f!=NULL) 
	{
			
    			

			while(fscanf(f,"%s %s %s  %s %s %s \n",li.specialite ,li.jour ,li.mois,li.annee,li.heure,li.num_seance)!=EOF)
			{
    				if(strcmp(li.num_seance,num)!=0)
    				{	
				  fprintf(j,"%s %s %s  %s %s %s \n",li.specialite ,li.jour ,li.mois,li.annee,li.heure,li.num_seance);
    				}
			}
			fclose(f);
			fclose(j);

			remove("liste.txt");
			rename("liste.tmp.txt","liste.txt");

	}
}
void modifier_seance(char num[],listes lm)
{	
	FILE*f ,*j;
    	listes li;

    	f=fopen("liste.txt","r+");
	    j=fopen("liste.tmp.txt","a+");
	if(f!=NULL) 
	{
			
    			

			while(fscanf(f,"%s %s %s  %s %s %s \n",li.specialite ,li.heure,li.jour ,li.mois,li.annee,li.num_seance)!=EOF)
			{
    				if(strcmp(li.num_seance,num)!=0)
    				{	
				  fprintf(j,"%s %s %s  %s %s %s \n",li.specialite ,li.heure,li.jour ,li.mois,li.annee,li.num_seance);
    				}
    				else{
					 fprintf(j,"%s %s %s  %s %s %s \n",lm.specialite ,lm.heure,lm.jour ,lm.mois,lm.annee,lm.num_seance);


    				}
			}
			fclose(f);
			fclose(j);

			remove("liste.txt");
			rename("liste.tmp.txt","liste.txt");

	}
}

