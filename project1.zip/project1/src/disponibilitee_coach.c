#include <stdio.h>
#include <string.h>


#include "disponibilitee_coach.h"
enum 
{
       JOUR_C,
       MOIS_C,
       ANNEE_C,
       HEURE_C,
       DUREE_C,
       SPECIALITE_C,
       NOMBRE_ADHERANT_C,
       COLUMNS
};

void disponibilitee_coach(GtkWidget *liste) 
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char jour_c[10];
	char mois_c[10];
	char annee_c[10];
        char heure_c[10];
        char duree_c[10];
        char specialite_c[30];
        char nombre_adherant_c[10];
        store=NULL;

       FILE *k;
	
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" jour_c", renderer, "text",JOUR_C, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" mois_c", renderer, "text",MOIS_C, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" annee_c", renderer, "text",ANNEE_C, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" heure_c", renderer, "text",HEURE_C, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" duree_c", renderer, "text",DUREE_C, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
               
                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" specialite_c", renderer, "text",SPECIALITE_C, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" nombre_adherant_c", renderer, "text",NOMBRE_ADHERANT_C, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
                
	
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	k = fopen("disponibilitee_coach.txt", "r");
	
	if(k==NULL)
	{

		return;
	}		
	else 

	{ k = fopen("disponibilitee_coach.txt", "a+");
              while(fscanf(k,"%s %s %s %s %s %s %s\n",jour_c,mois_c,annee_c,heure_c,duree_c,specialite_c, nombre_adherant_c)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, JOUR_C, jour_c, MOIS_C, mois_c, ANNEE_C, annee_c, HEURE_C, heure_c, DUREE_C, duree_c, SPECIALITE_C, specialite_c, NOMBRE_ADHERANT_C, nombre_adherant_c -1); 
		}
		fclose(k);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}
