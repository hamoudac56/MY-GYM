#include <gtk/gtk.h>


typedef struct 
{
        char jour_c[10];
	char mois_c[10];
	char annee_c[10];
        char heure_c[10];
        char duree_c[10];
        char specialite_c[30];
        char nombre_adherant_c[10];
} disponibilitee;
void disponibilitee_coach(GtkWidget *liste);

