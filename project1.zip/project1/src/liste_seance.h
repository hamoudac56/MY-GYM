#include <gtk/gtk.h>

typedef struct
{
        char specialite[100];
        char heure[50];
	char jour[50];
	char mois[50];
	char annee[50];
        char num_seance[50];
	
	
} listes;


int ver (char option[]);
void afficher_listes(GtkWidget *liste);
void supprimer_seance(char num1[10]);
void modifier_seance(char num[],listes lm);
