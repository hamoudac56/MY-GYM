
typedef struct
{
char specialite[100];
int jour;
int mois;
int annee;
int heure;
int num_seance;



}seance;

void ajouter_seance(seance s);

